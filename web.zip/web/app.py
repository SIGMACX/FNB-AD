from flask import Flask, request, render_template, send_from_directory, url_for, jsonify
import os
import sys
import shutil
from pathlib import Path
from werkzeug.utils import secure_filename

# Add web_infer directory to sys.path
current_dir = Path(__file__).resolve().parent
sys.path.append(str(current_dir))

from main import main  # Import main function from web_infer directory

UPLOAD_FOLDER = os.path.join(current_dir, 'static/uploads')
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'jpg', 'jpeg', 'png'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def ensure_upload_folder():
    # Ensure upload folder exists
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        file_ext = filename.rsplit('.', 1)[1].lower()
        
        # Return the URL and file type of the uploaded file
        return jsonify(original_file=url_for('uploaded_file', filename=filename, _external=True), file_type=file_ext)
    return jsonify({"error": "Invalid file type"})

@app.route('/inference', methods=['POST'])
def inference():
    if 'file' not in request.files:
        return jsonify({"error": "No file part"})
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No selected file"})

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        # Assuming main function processes the file and returns the path of the result
        result_path, final_results = main(file_path)
        result_filename = os.path.basename(result_path)

        # Ensure the upload folder exists
        ensure_upload_folder()

        # Copy the result to the upload folder
        shutil.copy(result_path, os.path.join(app.config['UPLOAD_FOLDER'], result_filename))

        # Return the URL of the inference result and the final results
        return jsonify(result_file=url_for('uploaded_file', filename=result_filename, _external=True), final_results=final_results)
    return jsonify({"error": "Invalid file type"})

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    ensure_upload_folder()
    app.run(debug=True)
