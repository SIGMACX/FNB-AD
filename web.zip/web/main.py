import sys
from pathlib import Path

current_dir = Path(__file__).resolve().parent
sys.path.append(str(current_dir.parent))

from tools.config import args
from tools.crop_image import jpg2png, resize_images, move_images
from utils.seg2image import map_segmentation_result
from class_method.seg_result_class_infer import seg_result_class_infer_save
from test_dou_class_u_net import seg_inference

import os
import cv2
import shutil
import time
import numpy as np
from ultralytics import YOLO
from tqdm import tqdm
import numpy as np
import re
from ultralytics import YOLO
from tools.config import args
from tools.crop_image import jpg2png, resize_images, move_images
from utils.seg2image import map_segmentation_result
from class_method.seg_result_class_infer import seg_result_class_infer_save
from test_dou_class_u_net import seg_inference

def save_video_frames_as_images(video_path, output_base_folder):
    video_name = os.path.splitext(os.path.basename(video_path))[0]
    folder_path = os.path.join(output_base_folder, f"{video_name}_results")
    output_folder = os.path.join(folder_path, "video2image")
    Path(output_folder).mkdir(parents=True, exist_ok=True)

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        print(f"Unable to open video files: {video_path}")
        return None, None, None, None

    video_fps = cap.get(cv2.CAP_PROP_FPS)

    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    saved_frame_index = 0
    with tqdm(total=total_frames, desc="Saving frames", unit="frames") as pbar:
        while True:
            ret, frame = cap.read()
            if not ret:
                break

            output_path = os.path.join(output_folder, f"frame_{saved_frame_index:04d}.jpg")
            cv2.imwrite(output_path, frame)
            saved_frame_index += 1
            pbar.update(1)

    cap.release()
    print(f"The conversion is complete and outputs a total of {saved_frame_index} images.")

    return folder_path, output_folder, video_name, video_fps

def images_to_video(image_folder, output_video_path, fps=30):
    def extract_number(filename):
        numbers = re.findall(r'\d+', filename.stem)
        return int(numbers[0]) if numbers else 0

    images = sorted(Path(image_folder).glob('*.jpg'), key=extract_number)

    if not images:
        print("No images found in the directory.")
        return

    frame = cv2.imread(str(images[0]))
    if frame is None:
        print("Failed to load the first image.")
        return
    height, width, layers = frame.shape

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

    for image_path in images:
        frame = cv2.imread(str(image_path))
        if frame is not None:
            out.write(frame)

    out.release()
    print(f"The predicted video has been saved to {output_video_path}")
    return output_video_path

def count_images_in_folder(folder_path):
    supported_extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.gif', '.tiff', '.webp']
    image_count = 0
    for entry in os.listdir(folder_path):
        if os.path.isfile(os.path.join(folder_path, entry)):
            _, ext = os.path.splitext(entry)
            if ext.lower() in supported_extensions:
                image_count += 1
    return image_count

def compare_prediction(abnormal_image_num, normal_image_num, video_image_nums, video_name, pred_acc):
    abnormal_ratio = abnormal_image_num / video_image_nums if video_image_nums > 0 else 0
    normal_ratio = normal_image_num / video_image_nums if video_image_nums > 0 else 0

    print(f"video_image_nums: {video_image_nums}, abnormal_image_num: {abnormal_image_num}, normal_image_num: {normal_image_num}")
    
    if abnormal_ratio > normal_ratio:
        result = "Abnormal"
    elif normal_ratio > abnormal_ratio:
        result = "Normal"
    else:
        result = "Inconclusive: Please recheck."

    print(f"Prediction for video {video_name} is likely: {result}, Pred_acc: {pred_acc}")
    
    # Create a dictionary with the result and prediction accuracy
    results_dic = {
        result:pred_acc
    }
    
    return results_dic


def apply_semi_transparent_red_overlay(mask_folder, target_folder, coords_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    for ori_filename in os.listdir(target_folder):
        if ori_filename.endswith(('.png', '.jpg')):
            target_image_path = os.path.join(target_folder, ori_filename)
            target_img = cv2.imread(target_image_path, cv2.IMREAD_UNCHANGED)
            if target_img is None:
                print(f"Failed to load: {target_image_path}")
                continue

            if target_img.shape[2] == 3:
                target_img = cv2.cvtColor(target_img, cv2.COLOR_BGR2BGRA)

            for mask_filename in os.listdir(mask_folder):
                if mask_filename.endswith(('.png', '.jpg')):
                    mask_image_path = os.path.join(mask_folder, mask_filename)
                    mask_img = cv2.imread(mask_image_path, cv2.IMREAD_GRAYSCALE)
                    if mask_img is None:
                        continue

                    for coords_filename in os.listdir(coords_folder):
                        if coords_filename.endswith('.txt'):
                            coords_file_path = os.path.join(coords_folder, coords_filename)
                            with open(coords_file_path, 'r') as file:
                                line = file.readline().strip()
                            _, x_center, y_center, width, height = map(float, line.split())

                            target_height, target_width = target_img.shape[:2]
                            rect_x = int((x_center - width / 2) * target_width)
                            rect_y = int((y_center - height / 2) * target_height)
                            rect_w = int(width * target_width)
                            rect_h = int(height * target_height)

                            white_pixels = np.where(mask_img >= 245)
                            white_coords = list(zip(white_pixels[0], white_pixels[1]))

                            for y, x in white_coords:
                                target_x = rect_x + int(x * rect_w / mask_img.shape[1])
                                target_y = rect_y + int(y * rect_h / mask_img.shape[0])
                                original_color = target_img[target_y, target_x][:3]
                                red_color = np.array([0, 0, 255], dtype=np.uint8)
                                new_color = cv2.addWeighted(original_color.astype(np.uint8), 0.5, red_color, 0.5, 0)
                                new_color = new_color.ravel()
                                target_img[target_y, target_x][:3] = new_color
                                target_img[target_y, target_x][3] = 127

            output_image_path = os.path.join(output_folder, f"output_{ori_filename}")
            cv2.imwrite(output_image_path, target_img)
            print(f"output_image_path: {output_image_path}")
    return output_image_path

def apply_video_semi_transparent_red_overlay(mask_folder, target_folder, coords_folder, output_folder):
    if not os.path.exists(output_folder):
        os.makedirs(output_folder)

    mask_files = {os.path.splitext(f)[0]: os.path.join(mask_folder, f) for f in os.listdir(mask_folder) if f.endswith(('.png', '.jpg'))}
    coords_files = {os.path.splitext(f)[0]: os.path.join(coords_folder, f) for f in os.listdir(coords_folder) if f.endswith('.txt')}

    processed_images = []

    for ori_filename in os.listdir(target_folder):
        file_root = os.path.splitext(ori_filename)[0]
        if ori_filename.endswith(('.png', '.jpg')):
            target_image_path = os.path.join(target_folder, ori_filename)
            output_image_path = os.path.join(output_folder, f"output_{ori_filename}")

            if file_root in mask_files and file_root in coords_files:
                target_img = cv2.imread(target_image_path, cv2.IMREAD_UNCHANGED)
                if target_img is None:
                    print(f"Failed to load: {target_image_path}")
                    continue

                if target_img.shape[2] == 3:
                    target_img = cv2.cvtColor(target_img, cv2.COLOR_BGR2BGRA)

                mask_image_path = mask_files[file_root]
                coords_file_path = coords_files[file_root]
                mask_img = cv2.imread(mask_image_path, cv2.IMREAD_GRAYSCALE)
                if mask_img is None:
                    continue

                with open(coords_file_path, 'r') as file:
                    line = file.readline().strip()
                _, x_center, y_center, width, height = map(float, line.split())

                target_height, target_width = target_img.shape[:2]
                rect_x = int((x_center - width / 2) * target_width)
                rect_y = int((y_center - height / 2) * target_height)
                rect_w = int(width * target_width)
                rect_h = int(height * target_height)

                white_pixels = np.where(mask_img >= 245)
                white_coords = list(zip(white_pixels[0], white_pixels[1]))

                for y, x in white_coords:
                    target_x = rect_x + int(x * rect_w / mask_img.shape[1])
                    target_y = rect_y + int(y * rect_h / mask_img.shape[0])
                    original_color = target_img[target_y, target_x][:3]
                    red_color = np.array([0, 0, 255], dtype=np.uint8)
                    new_color = cv2.addWeighted(original_color.astype(np.uint8), 0.5, red_color, 0.5, 0)
                    target_img[target_y, target_x][:3] = new_color.ravel()
                    target_img[target_y, target_x][3] = 127

                cv2.imwrite(output_image_path, target_img)
                processed_images.append(ori_filename)
            else:
                shutil.copy(target_image_path, output_image_path)
    return output_image_path

def clean_directory(path):
    if os.path.exists(path):
        shutil.rmtree(path)
    os.makedirs(path)


def main(video_path):
    base_root = "./web_infer"
    detection_model_path = './web_infer/models/yolo/best.pt'
    segmentation_model_path = './web_infer/models/seg/best_model.pt'
    classification_model_path = './web_infer/models/resnet34/best_model.pt'
    video2image_path = './web_infer/20240716_infer'
    start_time = time.time()
    count = 0
    gpu = args.gpu
    video_input_flag = False
    clean_directory(video2image_path)
    clean_directory(os.path.join(base_root, "runs"))
    if os.path.isfile(video_path) and video_path.endswith((".mp4", '.avi')):
        video_input_flag = True
        results_path, detection_image_path, video_name, video_fps = save_video_frames_as_images(video_path=video_path, 
                                output_base_folder=video2image_path)
    elif os.path.isfile(video_path) and video_path.endswith(('.jpg', '.jpeg', '.png')):
        detection_image_path = os.path.join(video2image_path, "image_tmp_path")
        results_path = video2image_path
        # if os.path.exists(detection_image_path):
        #     shutil.rmtree(detection_image_path)
        os.makedirs(detection_image_path, exist_ok=True)

        shutil.copy(video_path, detection_image_path)
        print(f"Copied {video_path} to {detection_image_path}")
    # inference Detection model
    D_model = YOLO(detection_model_path)
    D_model(source=detection_image_path, save_txt=True, save_crop=True,
            show_conf=False, show_labels=True, save=True, device=gpu)
    print("\033[94m 0 - Finished Detection inference! \033[0m")
    ori_detect_result = os.path.join(base_root, "runs/detect")
    shutil.move(ori_detect_result, results_path)
    detection_predimage_path = os.path.join(results_path, 'detect/predict')
    detected_results_path = os.path.join(results_path, 'detect/predict_image')
    move_images(detection_predimage_path, detected_results_path)
    if video_input_flag:
        images_to_video(os.path.join(results_path, 'detect/predict_image'), 
                        os.path.join(results_path, f'detect/{video_name}_pred.mp4'), 
                        fps=video_fps)

    # inference Segmentation model
    jpg2png(os.path.join(results_path,'detect/predict/crops/FNB/'), os.path.join(results_path,'detect/predict/crops/FNB_png/'))
    seg_inference(test_image_path=os.path.join(results_path,'detect/predict/crops/FNB_png/'),
                  num_classes=args.num_classes,
                  test_label_path=None,
                  input_channels=3,
                  snapshot_dir= segmentation_model_path,
                  save_path = os.path.join(results_path, "segmentation/Seg_results"),
                  is_ference=True, gpu=gpu, is_gpu=True)
    print("\033[94m 1 - Finished Segmentation inference! \033[0m")
    seg2img_path = os.path.join(results_path, "segmentation/Seg2imgs")
    if not os.path.exists(seg2img_path):
        os.makedirs(seg2img_path)
    resize_images(os.path.join(results_path,'detect/predict/crops/FNB_png/'), 
                  os.path.join(results_path,'detect/predict/crops/FNB_png/'), 
                  (128,128))
    for filename in os.listdir(os.path.join(results_path, "segmentation/Seg_results/seg_result")):
        if filename.endswith(".png"):
            count += 1
            origin_image_path = os.path.join(results_path,'detect/predict/crops/FNB_png/', filename)
            seg_result_path = os.path.join(results_path, "segmentation/Seg_results/seg_result", filename)
            seg_for_image_output_path = os.path.join(seg2img_path, filename)
            map_segmentation_result(original_image_path=origin_image_path,
                                    segmentation_result_path=seg_result_path, output_path=seg_for_image_output_path)
    print("\033[94m 2 - Finished mapping of segmentation to image! \033[0m")
    _, pred_acc, results_dic = seg_result_class_infer_save(dataset_root=seg2img_path, num_classes=args.class_num_classes, 
                                snapshot_dir= classification_model_path, 
                                gpu=gpu, 
                                output_dir=os.path.join(results_path, "class/predict/"), 
                                is_gpu=True)
    print(f"pred_acc: {pred_acc}, results_dic: {results_dic}")
    print('\033[94m 3 - Finished Classification inference! \033[0m')
    if video_input_flag:
        video_image_nums = count_images_in_folder(os.path.join(results_path,"video2image"))
        abnormal_image_num = count_images_in_folder(os.path.join(results_path, "class/predict/Abnormal"))
        normal_image_num = count_images_in_folder(os.path.join(results_path, "class/predict/Normal"))
        final_result = compare_prediction(abnormal_image_num, normal_image_num, video_image_nums, video_name, pred_acc)
        print(f"final_result: {final_result}")
        apply_video_semi_transparent_red_overlay(mask_folder = os.path.join(results_path, "segmentation/Seg_results/seg_result"),
                                        coords_folder = os.path.join(results_path, "detect/predict/labels"),
                                        target_folder = os.path.join(results_path, "detect/predict_image"),
                                        output_folder = os.path.join(video2image_path,"final_output/images"))
        output_path = images_to_video(os.path.join(video2image_path, "final_output/images"), 
                        os.path.join(video2image_path, f'final_output/{video_name}_final_pred.mp4'),
                        fps=video_fps)
    else:
        output_path = apply_semi_transparent_red_overlay(mask_folder = os.path.join(results_path, "segmentation/Seg_results/seg_result"),
                                        coords_folder = os.path.join(base_root, "20240716_infer/detect/predict/labels"),
                                        target_folder = os.path.join(results_path, "detect/predict_image"),
                                        output_folder = os.path.join(video2image_path,"final_output/images"))
        final_result = results_dic
        
    end_time = time.time()
    total_time = end_time - start_time
    single_time = total_time / count
    print(f"\033[95m Inference completed total in {total_time:.6f} seconds; \033[0m"
          f"\033[95m Single image inference in {single_time:.6f} seconds; \033[0m")
    return output_path, final_result
 